import { Link } from "@tanstack/react-router";
import { Mail, Phone, MapPin } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="border-t border-border mt-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16 grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-4">// Channel</div>
          <h3 className="font-display text-2xl font-medium leading-tight max-w-xs">
            Looking for a curious cyber-mind on your team?
          </h3>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 mt-6 text-sm font-mono uppercase tracking-widest text-glow hover:translate-x-1 transition"
          >
            Open transmission →
          </Link>
        </div>

        <div className="space-y-3 font-mono text-sm">
          <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground mb-4">// Direct</div>
          <a href="mailto:hingeshresta07@gmail.com" className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition">
            <Mail size={14} className="text-glow" /> hingeshresta07@gmail.com
          </a>
          <a href="tel:+919989434206" className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition">
            <Phone size={14} className="text-glow" /> +91 99894 34206
          </a>
          <div className="flex items-center gap-3 text-muted-foreground">
            <MapPin size={14} className="text-glow" /> Hanamkonda, India
          </div>
        </div>

        <div className="font-mono text-xs space-y-2 md:text-right">
          <div className="uppercase tracking-[0.3em] text-muted-foreground mb-4">// Status</div>
          <div className="text-foreground">SYS_BUILD: 2026.04</div>
          <div className="text-glow">UPLINK: STABLE</div>
          <div className="text-muted-foreground">© {new Date().getFullYear()} Hinge Shresta</div>
        </div>
      </div>
    </footer>
  );
}
