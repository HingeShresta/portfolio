import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/projects", label: "Projects" },
  { to: "/certifications", label: "Certifications" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/60 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full rounded-full bg-glow pulse-dot" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-glow" />
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground group-hover:text-foreground transition">
            hinge.shresta<span className="text-glow">/</span>sec
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-1 glass-panel rounded-full px-2 py-1.5">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="px-4 py-1.5 text-xs font-mono uppercase tracking-widest text-muted-foreground rounded-full transition hover:text-foreground"
              activeProps={{ className: "px-4 py-1.5 text-xs font-mono uppercase tracking-widest rounded-full bg-glow/10 text-glow" }}
              activeOptions={{ exact: true }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <Link
          to="/contact"
          className="hidden md:inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-foreground hover:text-glow transition"
        >
          <span className="size-1.5 rounded-full bg-glow shadow-[0_0_8px_var(--glow)]" />
          Available
        </Link>

        <button
          onClick={() => setOpen((v) => !v)}
          className="md:hidden p-2 text-foreground"
          aria-label="Toggle menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl">
          <nav className="flex flex-col px-6 py-4 gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                className="px-4 py-3 text-sm font-mono uppercase tracking-widest text-muted-foreground rounded-md transition hover:text-foreground hover:bg-secondary"
                activeProps={{ className: "px-4 py-3 text-sm font-mono uppercase tracking-widest text-glow rounded-md bg-glow/10" }}
                activeOptions={{ exact: true }}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
