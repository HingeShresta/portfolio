import { createFileRoute } from "@tanstack/react-router";
import profileImg from "@/assets/profile.jpeg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Hinge Shresta" },
      { name: "description", content: "B.Tech Cyber Security student at Sumathi Reddy Institute. Skills span Python, networking, ethical hacking and cloud security." },
      { property: "og:title", content: "About — Hinge Shresta" },
      { property: "og:description", content: "B.Tech Cyber Security student passionate about defensive networking and ethical hacking." },
    ],
  }),
  component: AboutPage,
});

const skills = {
  Programming: ["Python", "C"],
  Networking: ["TCP/IP", "VLANs", "Routing", "Switching"],
  Cybersecurity: ["Ethical Hacking", "Vulnerability Assessment", "Network Defense"],
  Tools: ["Wireshark", "Nessus", "OpenVAS", "Linux"],
  "Cloud & AI": ["Cloud Security Basics", "AI Fundamentals"],
};

const timeline = [
  {
    year: "2023 – 2027",
    title: "B.Tech in Cyber Security",
    org: "Sumathi Reddy Institute of Technology for Women, Hanamkonda",
    detail: "CGPA: 7.0 / 10 — focusing on network security, ethical hacking and applied cryptography.",
  },
  {
    year: "2023",
    title: "Senior Secondary (XII)",
    org: "Telangana State Board",
    detail: "Graduated with 88% — strong foundation in mathematics and computer science.",
  },
];

function AboutPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20">
      {/* Header */}
      <div className="grid grid-cols-12 gap-8 mb-24">
        <div className="col-span-12 lg:col-span-8">
          <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-4">// File 02 — Profile</div>
          <h1 className="font-display text-5xl md:text-7xl font-light leading-[0.95] tracking-tight">
            Curious by nature, <br />
            <span className="italic glow-text">methodical</span> by training.
          </h1>
          <p className="mt-8 text-lg text-muted-foreground leading-relaxed max-w-2xl">
            I'm a highly motivated cybersecurity student driven by a deep curiosity for ethical hacking and digital defense. I'm passionate about identifying vulnerabilities and strengthening system security through continuous learning and practical experimentation.
          </p>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed max-w-2xl">
            I'm seeking opportunities to grow as a cybersecurity professional while contributing to a safer digital ecosystem — across network defense, vulnerability assessment, and the AI fundamentals reshaping how we detect and respond to attacks.
          </p>
        </div>
        <div className="col-span-12 lg:col-span-4 lg:col-start-9">
          <div className="glass-panel rounded-2xl p-3 overflow-hidden">
            <div className="aspect-square rounded-xl overflow-hidden">
              <img src={profileImg} alt="Hinge Shresta" className="w-full h-full object-cover" />
            </div>
            <div className="px-3 py-4 font-mono text-xs flex justify-between text-muted-foreground">
              <span>HANAMKONDA · IN</span>
              <span className="text-glow">B.TECH '27</span>
            </div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <section className="mb-32">
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-3">// Education</div>
        <h2 className="font-display text-3xl md:text-4xl font-light mb-12">Academic record</h2>
        <div className="space-y-px">
          {timeline.map((t) => (
            <div
              key={t.title}
              className="grid grid-cols-12 gap-6 py-8 border-t border-border last:border-b group hover:bg-card/40 transition"
            >
              <div className="col-span-12 md:col-span-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">
                {t.year}
              </div>
              <div className="col-span-12 md:col-span-9">
                <h3 className="font-display text-2xl font-medium group-hover:text-glow transition">{t.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{t.org}</p>
                <p className="mt-3 text-foreground/80 leading-relaxed max-w-2xl">{t.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Skills */}
      <section>
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-3">// Stack</div>
        <h2 className="font-display text-3xl md:text-4xl font-light mb-12">Technical toolkit</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(skills).map(([category, items]) => (
            <div key={category} className="glass-panel rounded-2xl p-6 hover:border-glow/30 transition">
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-glow mb-4">{category}</div>
              <div className="flex flex-wrap gap-2">
                {items.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1.5 text-xs font-mono rounded-full bg-secondary/60 border border-border text-foreground/90"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
