import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck } from "lucide-react";

export const Route = createFileRoute("/certifications")({
  head: () => ({
    meta: [
      { title: "Certifications — Hinge Shresta" },
      { name: "description", content: "Cisco CCNA, Cyber Threat Management, Ethical Hacker, Network Defense, Python Essentials, and Modern AI." },
      { property: "og:title", content: "Certifications — Hinge Shresta" },
      { property: "og:description", content: "Cisco-stack certifications spanning networking, security, ethical hacking and AI." },
    ],
  }),
  component: CertsPage,
});

const certs = [
  { name: "CCNA: Introduction to Networks", issuer: "Cisco", date: "Mar 2026", track: "Networking" },
  { name: "CCNA: Switching, Routing & Wireless Essentials", issuer: "Cisco", date: "Mar 2026", track: "Networking" },
  { name: "CCNA: Enterprise Networking, Security & Automation", issuer: "Cisco", date: "Mar 2026", track: "Networking" },
  { name: "Cyber Threat Management", issuer: "Cisco", date: "Apr 2026", track: "Security" },
  { name: "Ethical Hacker", issuer: "Cisco", date: "Apr 2026", track: "Security" },
  { name: "Network Defense", issuer: "Cisco", date: "Apr 2026", track: "Security" },
  { name: "Python Essentials 1 & 2", issuer: "Cisco", date: "Apr 2026", track: "Programming" },
  { name: "Introduction to Modern AI", issuer: "Cisco", date: "Nov 2025", track: "AI" },
];

const trackColor: Record<string, string> = {
  Networking: "text-glow border-glow/30 bg-glow/5",
  Security: "text-accent border-accent/30 bg-accent/5",
  Programming: "text-foreground border-border bg-secondary/40",
  AI: "text-foreground border-border bg-secondary/40",
};

function CertsPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20">
      <div className="mb-20 max-w-3xl">
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-4">// File 04 — Credentials</div>
        <h1 className="font-display text-5xl md:text-7xl font-light leading-[0.95] tracking-tight">
          Certified across the <span className="italic glow-text">Cisco stack</span>.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
          Eight credentials covering networking, security operations, ethical hacking, programming and applied AI — all earned through Cisco Networking Academy.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {certs.map((c, i) => (
          <div
            key={c.name}
            className="group glass-panel rounded-2xl p-6 hover:border-glow/40 hover:-translate-y-0.5 transition-all"
          >
            <div className="flex items-start justify-between gap-4 mb-6">
              <div className="size-11 rounded-xl bg-glow/10 border border-glow/20 flex items-center justify-center text-glow">
                <BadgeCheck size={20} strokeWidth={1.5} />
              </div>
              <span className="font-mono text-[10px] text-muted-foreground">CERT_{String(i + 1).padStart(2, "0")}</span>
            </div>
            <div className="space-y-3">
              <h3 className="font-display text-xl font-medium leading-snug group-hover:text-glow transition">{c.name}</h3>
              <div className="flex items-center justify-between gap-3">
                <div className="font-mono text-xs text-muted-foreground">{c.issuer} · {c.date}</div>
                <span className={`px-2.5 py-1 rounded-full border text-[10px] font-mono uppercase tracking-wider ${trackColor[c.track]}`}>
                  {c.track}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
