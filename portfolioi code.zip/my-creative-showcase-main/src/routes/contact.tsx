import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, ArrowUpRight } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Hinge Shresta" },
      { name: "description", content: "Get in touch with Hinge Shresta for cybersecurity internships, collaborations and projects." },
      { property: "og:title", content: "Contact — Hinge Shresta" },
      { property: "og:description", content: "Open to Cisco virtual internships and cybersecurity collaborations." },
    ],
  }),
  component: ContactPage,
});

const channels = [
  { icon: Mail, label: "Email", value: "hingeshresta07@gmail.com", href: "mailto:hingeshresta07@gmail.com" },
  { icon: Phone, label: "Phone", value: "+91 99894 34206", href: "tel:+919989434206" },
  { icon: MapPin, label: "Location", value: "Hanamkonda, Telangana, India", href: null },
];

function ContactPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20">
      <div className="grid grid-cols-12 gap-8">
        <div className="col-span-12 lg:col-span-7">
          <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-4">// File 05 — Channel</div>
          <h1 className="font-display text-5xl md:text-7xl font-light leading-[0.95] tracking-tight mb-8">
            Open <span className="italic glow-text">transmission</span>.
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-xl">
            Whether it's a virtual internship, a CTF team, or a real-world security project — I'd love to hear what you're building. Drop me a message and I'll get back within 48 hours.
          </p>

          <div className="mt-12 space-y-px">
            {channels.map(({ icon: Icon, label, value, href }) => {
              const content = (
                <div className="group grid grid-cols-12 gap-4 py-6 border-t border-border last:border-b items-center transition hover:bg-card/40 px-2 -mx-2">
                  <div className="col-span-12 md:col-span-3 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    <Icon size={14} className="text-glow" />
                    {label}
                  </div>
                  <div className="col-span-12 md:col-span-8 font-display text-xl md:text-2xl font-light group-hover:text-glow transition">
                    {value}
                  </div>
                  <div className="hidden md:flex md:col-span-1 justify-end text-muted-foreground group-hover:text-glow transition">
                    {href && <ArrowUpRight size={18} />}
                  </div>
                </div>
              );
              return href ? (
                <a key={label} href={href}>{content}</a>
              ) : (
                <div key={label}>{content}</div>
              );
            })}
          </div>
        </div>

        <div className="col-span-12 lg:col-span-5 lg:col-start-8">
          <div className="glass-panel rounded-3xl p-8 sticky top-24 scanlines relative overflow-hidden">
            <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-glow mb-8">// Status report</div>

            <dl className="space-y-6 font-mono text-sm">
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <dt className="text-muted-foreground text-xs uppercase tracking-widest">Availability</dt>
                <dd className="text-glow flex items-center gap-2">
                  <span className="size-1.5 rounded-full bg-glow shadow-[0_0_8px_var(--glow)]" />
                  Open
                </dd>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <dt className="text-muted-foreground text-xs uppercase tracking-widest">Looking for</dt>
                <dd className="text-foreground text-right">Cisco Internship</dd>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <dt className="text-muted-foreground text-xs uppercase tracking-widest">Response</dt>
                <dd className="text-foreground">~ 48 hrs</dd>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border">
                <dt className="text-muted-foreground text-xs uppercase tracking-widest">Timezone</dt>
                <dd className="text-foreground">IST (UTC+5:30)</dd>
              </div>
              <div className="flex justify-between items-center">
                <dt className="text-muted-foreground text-xs uppercase tracking-widest">Format</dt>
                <dd className="text-foreground">Remote / Hybrid</dd>
              </div>
            </dl>

            <a
              href="mailto:hingeshresta07@gmail.com"
              className="mt-10 w-full inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs uppercase tracking-widest px-6 py-4 rounded-full hover:shadow-[var(--shadow-glow)] transition-all"
            >
              Send a message
              <ArrowUpRight size={14} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
