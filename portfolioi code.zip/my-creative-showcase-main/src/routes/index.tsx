import { createFileRoute, Link } from "@tanstack/react-router";
import profileImg from "@/assets/profile.jpeg";
import { ArrowRight, Shield, Network, Terminal, Cloud } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hinge Shresta — Cybersecurity & Networking Portfolio" },
      { name: "description", content: "Aspiring cybersecurity engineer building secure networks. Cisco CCNA certified, specialised in vulnerability management & ethical hacking." },
      { property: "og:title", content: "Hinge Shresta — Cybersecurity Portfolio" },
      { property: "og:description", content: "Aspiring cybersecurity engineer building secure networks." },
    ],
  }),
  component: Index,
});

const stats = [
  { value: "5000+", label: "Packets analysed" },
  { value: "50+", label: "Systems audited" },
  { value: "8", label: "Cisco certifications" },
  { value: "95%", label: "Detection accuracy" },
];

const focusAreas = [
  { icon: Shield, label: "Vulnerability Management", desc: "Nessus · OpenVAS · CVSS scoring" },
  { icon: Network, label: "Network Defense", desc: "TCP/IP · VLANs · Routing & Switching" },
  { icon: Terminal, label: "Ethical Hacking", desc: "Recon · Exploitation · Reporting" },
  { icon: Cloud, label: "Cloud Security", desc: "IAM · Hardening · Compliance" },
];

function Index() {
  return (
    <div className="relative">
      {/* HERO */}
      <section className="relative max-w-7xl mx-auto px-6 lg:px-10 pt-20 pb-32">
        <div className="grid grid-cols-12 gap-8 items-center">
          <div className="col-span-12 lg:col-span-7 space-y-8">
            <div className="inline-flex items-center gap-3 glass-panel rounded-full px-4 py-1.5">
              <span className="size-1.5 rounded-full bg-glow shadow-[0_0_10px_var(--glow)]" />
              <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                Open to Cisco virtual internships · 2026
              </span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-light leading-[0.95] tracking-tighter">
              Curious about <br />
              <span className="glow-text font-medium italic">ethical hacking</span>,<br />
              committed to defense.
            </h1>

            <p className="max-w-xl text-lg text-muted-foreground leading-relaxed">
              I'm <span className="text-foreground font-medium">Hinge Shresta</span> — a highly motivated cybersecurity student driven by a deep curiosity for ethical hacking and digital defense. Passionate about identifying vulnerabilities and strengthening system security through continuous learning and practical experimentation, seeking opportunities to grow while contributing to a safer digital ecosystem.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <Link
                to="/projects"
                className="group inline-flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs uppercase tracking-widest px-6 py-3.5 rounded-full hover:shadow-[var(--shadow-glow)] transition-all"
              >
                View case studies
                <ArrowRight size={14} className="group-hover:translate-x-1 transition" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 glass-panel font-mono text-xs uppercase tracking-widest px-6 py-3.5 rounded-full hover:bg-secondary transition"
              >
                Get in touch
              </Link>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-5 relative">
            <div className="relative float-slow">
              {/* Decorative HUD frame */}
              <div className="absolute -inset-4 bg-gradient-to-br from-glow/30 via-transparent to-glow-soft/20 rounded-[2rem] blur-2xl" />
              <div className="relative glass-panel rounded-[1.75rem] p-3 overflow-hidden scanlines">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-secondary">
                  <img
                    src={profileImg}
                    alt="Hinge Shresta"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />

                  {/* HUD corners */}
                  <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-glow rounded-tl" />
                  <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-glow rounded-tr" />
                  <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-glow rounded-bl" />
                  <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-glow rounded-br" />

                  {/* Bottom label */}
                  <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end font-mono text-[10px] uppercase tracking-widest">
                    <div>
                      <div className="text-glow">ID_001</div>
                      <div className="text-foreground/80">Hinge Shresta</div>
                    </div>
                    <div className="text-right text-muted-foreground">
                      <div>Cyber.Sec</div>
                      <div className="text-glow">VERIFIED</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS BAR */}
      <section className="border-y border-border bg-card/40 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 grid grid-cols-2 md:grid-cols-4 divide-x divide-border">
          {stats.map((s) => (
            <div key={s.label} className="px-6 py-8 text-center first:pl-0">
              <div className="font-display text-3xl md:text-4xl font-medium glow-text">{s.value}</div>
              <div className="mt-2 text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FOCUS AREAS */}
      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-32">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-3">// Capabilities</div>
            <h2 className="font-display text-4xl md:text-5xl font-light tracking-tight max-w-2xl">
              Operating across the modern <span className="italic glow-text">attack surface</span>.
            </h2>
          </div>
          <Link to="/about" className="font-mono text-xs uppercase tracking-widest text-muted-foreground hover:text-glow transition self-start md:self-end">
            Read more about me →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {focusAreas.map(({ icon: Icon, label, desc }, i) => (
            <div
              key={label}
              className="group glass-panel rounded-2xl p-6 hover:border-glow/40 hover:-translate-y-1 transition-all duration-500"
            >
              <div className="flex items-start justify-between mb-12">
                <div className="size-11 rounded-xl bg-glow/10 border border-glow/20 flex items-center justify-center text-glow group-hover:bg-glow/20 transition">
                  <Icon size={20} strokeWidth={1.5} />
                </div>
                <span className="font-mono text-[10px] text-muted-foreground">0{i + 1}</span>
              </div>
              <h3 className="font-display text-lg font-medium mb-2">{label}</h3>
              <p className="font-mono text-xs text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="max-w-7xl mx-auto px-6 lg:px-10 pb-12">
        <div className="relative glass-panel rounded-3xl p-10 md:p-16 overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-20" />
          <div className="absolute -top-20 -right-20 size-80 rounded-full bg-glow/20 blur-3xl" />
          <div className="relative grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            <div className="md:col-span-2">
              <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-3">// Next mission</div>
              <h3 className="font-display text-3xl md:text-4xl font-light tracking-tight">
                Have a security challenge worth solving? <span className="italic glow-text">Let's talk.</span>
              </h3>
            </div>
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs uppercase tracking-widest px-6 py-4 rounded-full hover:shadow-[var(--shadow-glow)] transition-all md:justify-self-end"
            >
              Initiate handshake
              <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
