import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Hinge Shresta" },
      { name: "description", content: "Selected cybersecurity projects: vulnerability management, cloud security, network traffic analysis, and a secure password generator." },
      { property: "og:title", content: "Projects — Hinge Shresta" },
      { property: "og:description", content: "Vulnerability management, cloud security, network analysis and more." },
    ],
  }),
  component: ProjectsPage,
});

const projects = [
  {
    id: "01",
    title: "Vulnerability Management",
    date: "Apr 2026",
    tag: "Defensive Security",
    summary:
      "End-to-end vulnerability assessment program across 50+ systems with prioritised remediation and patch management.",
    bullets: [
      "Executed assessments using Nessus and OpenVAS, achieving a 40% reduction in critical security risks.",
      "Prioritised high-risk vulnerabilities using CVSS scoring, decreasing exposure time by 35% within 2-week cycles.",
      "Implemented patch management and system hardening, reducing recurring vulnerabilities by 25%.",
    ],
    stack: ["Nessus", "OpenVAS", "CVSS", "Linux"],
  },
  {
    id: "02",
    title: "Cloud Security Hardening",
    date: "Apr 2026",
    tag: "Cloud Security",
    summary:
      "Designed access governance and secure storage configuration for cloud workloads aligned with the shared responsibility model.",
    bullets: [
      "Configured IAM policies and RBAC across 10+ cloud resources, strengthening access governance.",
      "Applied network controls and secure storage configurations, lowering misconfiguration incidents by 30%.",
      "Enforced shared responsibility practices, improving compliance readiness with industry standards.",
    ],
    stack: ["IAM", "RBAC", "Cloud Storage", "Compliance"],
  },
  {
    id: "03",
    title: "Network Traffic Analysis",
    date: "Mar 2026",
    tag: "Threat Detection",
    summary:
      "Packet-level threat hunting at scale — discovered suspicious flows hidden inside everyday TCP/IP, DNS and HTTPS traffic.",
    bullets: [
      "Analysed 5000+ packets in Wireshark to detect anomalies with 95% accuracy.",
      "Monitored TCP/IP, DNS, and HTTP/HTTPS patterns, cutting troubleshooting time by 40%.",
      "Conducted packet inspection to identify 15+ suspicious connections, enhancing incident detection.",
    ],
    stack: ["Wireshark", "TCP/IP", "DNS", "HTTPS"],
  },
  {
    id: "04",
    title: "Secure Password Generator",
    date: "Nov 2024 – Jan 2025",
    tag: "Applied Cryptography",
    summary:
      "A Python utility producing high-entropy passwords resistant to brute-force and dictionary attacks.",
    bullets: [
      "Built a generator producing 1000+ secure combinations against brute-force and dictionary attacks.",
      "Designed multi-layer complexity algorithms, increasing strength by 50% and improving compliance.",
      "Optimised randomisation logic, achieving a 20% improvement in execution speed.",
    ],
    stack: ["Python", "Cryptography", "Algorithms"],
  },
];

function ProjectsPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20">
      <div className="mb-20 max-w-3xl">
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-glow mb-4">// File 03 — Operations</div>
        <h1 className="font-display text-5xl md:text-7xl font-light leading-[0.95] tracking-tight">
          Selected <span className="italic glow-text">case studies</span>.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
          Hands-on security work across vulnerability management, cloud hardening, and network forensics — measured by the outcomes that matter.
        </p>
      </div>

      <div className="space-y-px">
        {projects.map((p) => (
          <article
            key={p.id}
            className="group grid grid-cols-12 gap-6 py-12 border-t border-border last:border-b transition-all hover:bg-card/30 px-2 -mx-2 rounded-none"
          >
            <div className="col-span-12 md:col-span-2 space-y-2 font-mono text-xs uppercase tracking-widest text-muted-foreground">
              <div className="text-glow">[ {p.id} ]</div>
              <div>{p.date}</div>
              <div className="text-foreground/80">{p.tag}</div>
            </div>

            <div className="col-span-12 md:col-span-7 space-y-5">
              <h2 className="font-display text-3xl md:text-4xl font-medium tracking-tight group-hover:text-glow transition">
                {p.title}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">{p.summary}</p>
              <ul className="space-y-2.5 mt-4">
                {p.bullets.map((b, i) => (
                  <li key={i} className="flex gap-3 text-foreground/85 leading-relaxed">
                    <span className="text-glow font-mono text-xs mt-1.5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-span-12 md:col-span-3 flex flex-col justify-between gap-6">
              <div className="flex flex-wrap gap-2">
                {p.stack.map((s) => (
                  <span
                    key={s}
                    className="px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider rounded-full border border-glow/20 bg-glow/5 text-glow"
                  >
                    {s}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground group-hover:text-glow transition">
                Case study
                <ArrowUpRight size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
